"""Детерминированные проверки четырёх этапов запуска."""
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Any
import numpy as np
import pandas as pd
from .inputs import Inputs

RULES_PATH = Path(__file__).parent.parent / "rules.json"

def load_rules() -> Dict:
    with open(RULES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

RULES = load_rules()

def _checkpoint() -> pd.Timestamp:
    return pd.Timestamp(RULES["check_point_utc"])

def _check_result(check_id: str, title: str, status: str, summary: str,
                  source: str, input_hash: str, obstacles=None, next_action=None):
    return {
        "id": check_id, "title": title, "summary": summary, "mandatory": True,
        "status": status,
        "evidence": {"source": source, "rules": RULES["version"],
                     "checked_at": datetime.now(timezone.utc).isoformat(),
                     "input_hash": input_hash},
        "obstacles": obstacles or [], "next_action": next_action
    }

def _unavailable(stage_checks, source, reason, object_id, input_hash):
    return [_check_result(cid, title, "unavailable",
             f"Проверка невозможна: {reason}", source, input_hash,
             [{"check": cid, "reason": reason, "field": source, "asset": object_id}],
             "Восстановить входные данные и повторить проверку")
            for cid, title in stage_checks]

def _col(df, candidates):
    normalized = {str(c).casefold().replace(" ", "").replace("_", ""): c for c in df.columns}
    for candidate in candidates:
        key = candidate.casefold().replace(" ", "").replace("_", "")
        if key in normalized:
            return normalized[key]
    return None

def _numeric(df, column):
    return pd.to_numeric(df[column], errors="coerce") if column in df.columns else pd.Series(np.nan, index=df.index)

def _time_series_ok(df):
    if df is None or df.empty:
        return False, "Нет строк с временными метками."
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is None:
        return False, "Временные метки не имеют часового пояса UTC."
    if str(idx.tz) not in ("UTC", "UTC+00:00"):
        return False, "Временные метки должны быть в UTC."
    if idx.has_duplicates:
        return False, "Обнаружены повторяющиеся временные метки."
    return True, ""

def _check_time_step(df):
    if df is None or len(df) < 2:
        return False, []
    diffs = pd.Series(pd.DatetimeIndex(df.index).to_series().diff().dropna().dt.total_seconds().values)
    bad = diffs.index[diffs.ne(900)].tolist()
    return len(bad) == 0, bad

def _check_coverage(df, start, end):
    start, end = pd.Timestamp(start), pd.Timestamp(end)
    idx = pd.DatetimeIndex(df.index)
    selected = idx[(idx >= start) & (idx <= end)]
    months = len(set(selected.strftime("%Y-%m")))
    expected = int((end - start).total_seconds() // 900) + 1
    observed = len(selected.unique())
    return months >= int(RULES["history"]["months_required"]), observed, expected, months

def stage1(I) -> List[Dict]:
    oid = I.passport.get("object_id", I.folder.name)
    h = I.hashes()[1]
    input_error = next((e for e in I.input_errors if e["file"] in {"object.json", "invoice.csv"}), None)
    if I.inv is None or input_error:
        reason = input_error["message"] if input_error else "invoice.csv отсутствует или пуст."
        return _unavailable([
            ("S1.1","EAN"),("S1.2","Метки, дубли и шаг 15 минут"),
            ("S1.3","Покрытие истории 24 месяца"),("S1.4","Полнота истории"),
            ("S1.5","Знаки энергий"),("S1.6","Единицы измерения"),
            ("S1.7","Связь истории с объектом")],
            "invoice.csv", reason, oid, h)

    df = I.inv
    checks = []
    # S1.1: EANs from the passport; never infer identity from arbitrary CSV rows.
    gc = I.passport.get("grid_connection", {}) or {}
    eans = [gc.get("ean_offtake"), gc.get("ean_injection")]
    valid_eans = [str(x) for x in eans if x not in (None, "")]
    bad_eans = [x for x in valid_eans if not (x.isdigit() and len(x) == 18)]
    if len(valid_eans) != 2 or len(set(valid_eans)) != 2:
        bad_eans.append("EAN потребления/выдачи отсутствуют или совпадают")
    peer_eans = set(getattr(I, "peer_eans", []))
    duplicates = peer_eans.intersection(valid_eans)
    bad_eans.extend(sorted(duplicates))
    checks.append(_check_result("S1.1","EAN (18 цифр и привязка к объекту)",
        "pass" if not bad_eans else "fail",
        "EAN паспорта корректны и уникальны" if not bad_eans else f"Проблемы EAN: {bad_eans[:5]}",
        "object.json + invoice.csv", h,
        [{"check":"S1.1","reason":f"Некорректный или повторяющийся EAN: {x}","field":"grid_connection","asset":oid} for x in bad_eans],
        "Проверить EAN в паспорте и официальной выгрузке" if bad_eans else None))

    # S1.2: duplicate timestamps and strict 15-minute cadence.
    ok_time, time_reason = _time_series_ok(df)
    step_ok, bad_steps = _check_time_step(df)
    dup = pd.DatetimeIndex(df.index)[pd.DatetimeIndex(df.index).duplicated(keep=False)].unique().tolist()
    time_bad = (not ok_time) or bool(dup) or not step_ok
    obs = ([{"check":"S1.2","reason":time_reason,"field":"timestamp","asset":oid}] if not ok_time else [])
    obs += [{"check":"S1.2","reason":f"Дублирующаяся метка {x}","field":"timestamp","asset":oid} for x in dup[:100]]
    obs += [{"check":"S1.2","reason":f"Интервал между соседними строками не 15 минут (позиция {x})","field":"timestamp","asset":oid} for x in bad_steps[:100]]
    checks.append(_check_result("S1.2","Метки (UTC, без дублей, шаг 15 минут)",
        "pass" if not time_bad else "fail",
        "Метки уникальны, UTC, шаг 15 минут" if not time_bad else f"Нарушения меток: дублей {len(dup)}, неверных интервалов {len(bad_steps)}",
        "invoice.csv", h, obs, "Исправить временные метки и пропуски" if time_bad else None))

    # S1.3: coverage by configured 24-month window.
    start, end = RULES["history"]["window_start_utc"], RULES["history"]["window_end_utc"]
    coverage, observed, expected, months = _check_coverage(df, start, end)
    checks.append(_check_result("S1.3","Покрытие истории (24 месяца)",
        "pass" if coverage else "fail",
        f"Покрыто {months} месяцев; строк в окне {observed}/{expected}",
        "invoice.csv", h,
        [] if coverage else [{"check":"S1.3","reason":f"Покрыто {months} из {RULES['history']['months_required']} месяцев","field":"timestamp","asset":oid}],
        None if coverage else "Получить официальную историю за недостающие месяцы"))

    # S1.4: count valid raw/validated energy values in the configured interval.
    energy_col = _col(df, ["Grid.energy_kWh.offtake_invoice_validated (kWh)"])
    raw_col = _col(df, ["Grid.energy_kWh.offtake_invoice (kWh)", "energy_kWh", "value"])
    inj_col = _col(df, ["Grid.energy_kWh.injection_invoice (kWh)", "ca_kwh"])
    start_ts, end_ts = pd.Timestamp(start), pd.Timestamp(end)
    mask = (df.index >= start_ts) & (df.index <= end_ts)
    window = df.loc[mask]
    valid = pd.Series(False, index=window.index)
    if energy_col:
        valid |= pd.to_numeric(window[energy_col], errors="coerce").notna()
    if RULES["history"].get("fallback_validated_to_raw", True) and raw_col:
        valid |= pd.to_numeric(window[raw_col], errors="coerce").notna()
    if inj_col:
        valid |= pd.to_numeric(window[inj_col], errors="coerce").notna()
    completeness = 100.0 * valid.sum() / max(expected, 1)
    min_pct = float(RULES["history"].get("min_completeness_pct", 99.0))
    full = completeness >= min_pct
    checks.append(_check_result("S1.4","Полнота истории (validated/raw)",
        "pass" if full else "fail",
        f"Заполнено {completeness:.3f}% интервалов; порог {min_pct:.1f}%",
        "invoice.csv", h,
        [] if full else [{"check":"S1.4","reason":f"Полнота {completeness:.2f}% ниже {min_pct:.2f}%","field":"energy_kWh","asset":oid}],
        None if full else "Получить недостающие значения учёта"))

    # S1.5: offtake and injection energy are both non-negative quantities.
    off_col = raw_col
    inj_col = inj_col or _col(df, ["Grid.energy_kWh.injection_invoice_validated (kWh)"])
    off = pd.to_numeric(df[off_col], errors="coerce") if off_col else pd.Series(np.nan,index=df.index)
    inj = pd.to_numeric(df[inj_col], errors="coerce") if inj_col else pd.Series(np.nan,index=df.index)
    bad_sign = (off.dropna() < 0) | (inj.dropna() < 0)
    bad_idx = bad_sign[bad_sign].index.tolist()
    sign_ok = len(bad_idx)==0 and off.notna().any() and inj.notna().any()
    checks.append(_check_result("S1.5","Знаки энергий (offtake/injection ≥ 0)",
        "pass" if sign_ok else "fail",
        "Энергии потребления и выдачи неотрицательны" if sign_ok else f"Отрицательные значения или отсутствуют данные: {len(bad_idx)} нарушений",
        "invoice.csv", h,
        [{"check":"S1.5","reason":f"Отрицательная энергия в строке {x}","field":"energy_kWh","asset":oid} for x in bad_idx[:100]],
        None if sign_ok else "Проверить знаки и наличие обеих колонок энергий"))

    # S1.6: interval energy = absolute average power * 0.25 h; use both directions.
    power_col = _col(df, ["Grid.power_kW.invoice (kW)", "power_kW"])
    power = pd.to_numeric(df[power_col], errors="coerce").abs() if power_col else pd.Series(np.nan,index=df.index)
    total_energy = off.fillna(0) + inj.fillna(0)
    ratio = total_energy / (power * 0.25).replace(0, np.nan)
    usable = ratio.replace([np.inf,-np.inf],np.nan).dropna()
    tol = float(RULES["history"].get("unit_consistency_rel_tolerance", 0.15))
    share = float(((usable-1).abs() <= tol).mean()) if len(usable) else 0.0
    min_share = float(RULES["history"].get("unit_consistency_min_share", 0.85))
    units_ok = share >= min_share
    bad_units = (usable-1).abs() > tol
    checks.append(_check_result("S1.6","Единицы (E = |P| × 0,25 ч)",
        "pass" if units_ok else "fail",
        f"Соотношение энергии и мощности согласуется в {share:.1%} строк; порог {min_share:.1%}",
        "invoice.csv", h,
        [{"check":"S1.6","reason":f"Несогласованность E/P в строке {x}","field":"energy_kWh/power_kW","asset":oid} for x in bad_units[bad_units].index[:100]],
        None if units_ok else "Проверить единицы и коэффициенты преобразования"))

    # S1.7: object linkage and distinct EAN; peer values are injected by run_demo.
    linked = len(valid_eans)==2 and len(set(valid_eans))==2 and not duplicates
    checks.append(_check_result("S1.7","Связь истории с объектом",
        "pass" if linked else "fail",
        "История сопоставлена с EAN паспорта" if linked else "EAN истории не подтверждают привязку к объекту",
        "object.json + invoice.csv", h,
        [] if linked else [{"check":"S1.7","reason":"EAN отсутствуют, совпадают или повторяются у другого объекта","field":"grid_connection","asset":oid}],
        None if linked else "Сверить EAN официальной выгрузки с паспортом"))
    return checks

def stage2(I) -> List[Dict]:
    oid = I.passport.get("object_id", I.folder.name)
    h = I.hashes()[2]
    error = next((e for e in I.input_errors if e["file"] in {"object.json","telemetry.csv"}), None)
    if I.tel is None or error:
        return _unavailable([
            ("S2.1","Сигналы по паспорту"),("S2.2","Метки и часовой пояс UTC"),
            ("S2.3","Актуальность ≤ 30 минут"),("S2.4","Полнота ≥ 99% за 48 часов"),
            ("S2.5","Правдоподобие значений"),("S2.6","Физическая согласованность учёта")],
            "telemetry.csv", error["message"] if error else "telemetry.csv отсутствует.", oid, h)
    df=I.tel
    checks=[]
    required=list(I.passport.get("site_signals",[]))
    for asset in I.passport.get("assets",[]) or []:
        required.extend(asset.get("signals",[]) or [])
    required=list(dict.fromkeys(required))
    missing=[s for s in required if s not in df.columns]
    checks.append(_check_result("S2.1","Сигналы по паспорту (объект и активы)",
        "pass" if not missing else "fail",
        "Все обязательные сигналы присутствуют" if not missing else f"Отсутствуют сигналы: {missing[:12]}",
        "object.json + telemetry.csv",h,
        [{"check":"S2.1","reason":f"Отсутствует сигнал {s}","field":s,"asset":next((a.get("asset_id") for a in I.passport.get("assets",[]) if s in a.get("signals",[])),oid)} for s in missing[:100]],
        None if not missing else "Подключить отсутствующие сигналы активов"))

    utc_ok, utc_reason = _time_series_ok(df)
    source_utc = df.attrs.get("timestamp_source_has_utc", True)
    utc_ok = utc_ok and source_utc
    checks.append(_check_result("S2.2","Метки и часовой пояс UTC",
        "pass" if utc_ok else "fail",
        "Временные метки однозначно заданы в UTC" if utc_ok else (utc_reason or "В исходных метках нет явного UTC/смещения"),
        "telemetry.csv",h,
        [] if utc_ok else [{"check":"S2.2","reason":utc_reason or "В исходных timestamp отсутствует Z или UTC-смещение","field":"timestamp","asset":oid}],
        None if utc_ok else "Привести временные метки к ISO 8601 UTC"))

    checkpoint=_checkpoint()
    latest=pd.Timestamp(df.index.max())
    age=(checkpoint-latest).total_seconds()/60
    max_age=float(RULES["realtime"]["max_age_min"])
    fresh=(0 <= age <= max_age)
    checks.append(_check_result("S2.3","Актуальность телеметрии",
        "pass" if fresh else "fail",
        f"Последняя метка {latest.isoformat()}, возраст относительно точки проверки {age:.1f} мин",
        "telemetry.csv",h,
        [] if fresh else [{"check":"S2.3","reason":f"Возраст {age:.1f} мин; допустимо 0–{max_age:.0f} мин","field":"timestamp","asset":oid}],
        None if fresh else "Обновить телеметрию или уточнить точку проверки"))

    # Expected 15-minute samples in the 48-hour window, inclusive of both endpoints.
    window_start=checkpoint-pd.Timedelta(hours=float(RULES["realtime"]["window_hours"]))
    expected_idx=pd.date_range(window_start,checkpoint,freq="15min")
    observed_idx=pd.DatetimeIndex(df.index)
    observed_in_window=observed_idx[(observed_idx>=window_start)&(observed_idx<=checkpoint)]
    unique_count=len(observed_in_window.unique())
    completeness=100.0*unique_count/max(len(expected_idx),1)
    threshold=float(RULES["realtime"]["min_completeness_pct"])
    complete=completeness>=threshold
    checks.append(_check_result("S2.4","Полнота потока за 48 часов",
        "pass" if complete else "fail",
        f"Получено {unique_count}/{len(expected_idx)} интервалов ({completeness:.2f}%); порог {threshold:.1f}%",
        "telemetry.csv",h,
        [] if complete else [{"check":"S2.4","reason":f"Полнота {completeness:.2f}% ниже {threshold:.2f}%","field":"timestamp","asset":oid}],
        None if complete else "Восстановить пропущенные интервалы телеметрии"))

    # Physical plausibility: sentinels, PV non-negative, SoC in [0,100], grid power sign.
    sentinels=set(RULES["realtime"].get("sentinels",[]))
    issues=[]
    for col in df.columns:
        if col=="timestamp": continue
        values=pd.to_numeric(df[col],errors="coerce")
        bad=values.isin(sentinels)
        if bad.any():
            issues.append({"check":"S2.5","reason":f"Значение-заглушка в {col} ({int(bad.sum())} строк)","field":col,"asset":col.split(".")[0]})
        if ".power_kW" in col and (col.startswith("PV") or ".PV" in col):
            bad=values < 0
            if bad.any(): issues.append({"check":"S2.5","reason":f"Отрицательная мощность PV в {col}","field":col,"asset":col.split(".")[0]})
        if "SOC_%" in col:
            bad=(values<0)|(values>100)
            if bad.any(): issues.append({"check":"S2.5","reason":f"SoC вне диапазона 0–100% в {col}","field":col,"asset":col.split(".")[0]})
    gridp=_col(df,["Grid.power_kW (kW)"])
    offc=_col(df,["Grid.energy_kWh.offtake (kWh)"])
    injc=_col(df,["Grid.energy_kWh.injection (kWh)"])
    if gridp and offc and injc:
        gp=pd.to_numeric(df[gridp],errors="coerce")
        net=pd.to_numeric(df[offc],errors="coerce")-pd.to_numeric(df[injc],errors="coerce")
        valid=gp.notna()&net.notna()&(net.abs()>0.02)&(gp.abs()>0.02)
        mismatch=valid & (np.sign(gp)!=np.sign(net))
        mismatch_share=float(mismatch.sum()/valid.sum()) if valid.any() else 1.0
        allowed_mismatch=1.0-float(RULES["realtime"].get("consistency_min_share",0.85))
        if mismatch_share > allowed_mismatch:
            issues.append({"check":"S2.5","reason":f"Знак Grid.power_kW не соответствует направлению обмена в {mismatch_share:.1%} валидных строк (допуск {allowed_mismatch:.1%})","field":gridp,"asset":"Grid"})
    plausible=not issues
    checks.append(_check_result("S2.5","Правдоподобие телеметрии",
        "pass" if plausible else "fail",
        "Заглушек, недопустимых значений и ошибок знака не обнаружено" if plausible else f"Обнаружено проблем: {len(issues)}",
        "telemetry.csv",h,issues[:150],
        None if plausible else "Исправить знаки, диапазоны и значения-заглушки"))

    # Energy balance across grid, PV, batteries and site demand.
    offc=_col(df,["Grid.energy_kWh.offtake (kWh)"])
    injc=_col(df,["Grid.energy_kWh.injection (kWh)"])
    demandc=_col(df,["Demand.energy_kWh (kWh)"])
    pv_aggregate=[c for c in df.columns if c.startswith("PV") and "energy_kWh" in c and "total_production" in c]
    pvcols=pv_aggregate or [c for c in df.columns if c.startswith("PV") and "energy_kWh" in c and "production" in c]
    charge_aggregate=[c for c in df.columns if c.startswith("Battery") and "energy_kWh" in c and "total_charge" in c]
    discharge_aggregate=[c for c in df.columns if c.startswith("Battery") and "energy_kWh" in c and "total_discharge" in c]
    bat_charge=charge_aggregate or [c for c in df.columns if c.startswith("Battery") and "energy_kWh" in c and "charge" in c]
    bat_discharge=discharge_aggregate or [c for c in df.columns if c.startswith("Battery") and "energy_kWh" in c and "discharge" in c]
    if offc and injc and demandc:
        balance=pd.to_numeric(df[offc],errors="coerce")-pd.to_numeric(df[injc],errors="coerce")
        if pvcols:
            balance += df[pvcols].apply(pd.to_numeric,errors="coerce").fillna(0).sum(axis=1)
        if bat_discharge:
            balance += df[bat_discharge].apply(pd.to_numeric,errors="coerce").fillna(0).sum(axis=1)
        if bat_charge:
            balance -= df[bat_charge].apply(pd.to_numeric,errors="coerce").fillna(0).sum(axis=1)
        demand=pd.to_numeric(df[demandc],errors="coerce")
        residual=(balance-demand).abs()
        valid=residual.dropna()
        share=float((valid<=float(RULES["realtime"].get("consistency_tol_abs_kwh",0.05))).mean()) if len(valid) else 0.0
        min_share=float(RULES["realtime"].get("consistency_min_share",0.85))
        consistent=share>=min_share
        summary=f"Энергетический баланс согласуется в {share:.1%} интервалов; порог {min_share:.1%}"
        obstacles=[] if consistent else [{"check":"S2.6","reason":summary,"field":"Grid/Demand/PV/Battery energy","asset":oid}]
    else:
        consistent=False
        summary="Для энергетического баланса отсутствуют обязательные site-сигналы"
        obstacles=[{"check":"S2.6","reason":summary,"field":"site_signals","asset":oid}]
    checks.append(_check_result("S2.6","Согласованность энергетического баланса",
        "pass" if consistent else "fail",summary,"telemetry.csv",h,obstacles,
        None if consistent else "Проверить привязку сигналов и баланс энергий"))
    return checks

def stage3(I) -> List[Dict]:
    h=I.hashes()[3]
    assets=I.passport.get("assets",[]) or []
    if not assets:
        return [
            _check_result("S3.1","Исторический отклик управления","not_applicable",
                          "У объекта нет управляемых активов; проверка не применима",
                          "object.json",h),
            _check_result("S3.2","Тест контура на имитаторе","not_applicable",
                          "У объекта нет управляемых активов; тест не требуется",
                          "simulator",h)]
    mode=(I.sim or {}).get("mode","ok")
    count=int(RULES["control"].get("sim_commands_per_asset",3))
    sim_records=[]
    for asset in assets:
        sent_count=ack_count=response_count=0
        for command_no in range(1,count+1):
            sent=True
            acknowledged=sent and mode not in ("no_ack","offline")
            # The simulator returns a deterministic measured response; no device is contacted.
            target_kw=10.0
            actual_kw=target_kw if mode not in ("no_response","offline") else 0.0
            responded=acknowledged and abs(actual_kw-target_kw) <= float(RULES["control"].get("tolerance_kw_abs",1.0))
            sent_count += int(sent)
            ack_count += int(acknowledged)
            response_count += int(responded)
        sim_records.append({"asset_id":asset.get("asset_id"),"sent":sent_count,
                            "acknowledged":ack_count,"responded":response_count})
    total_sent=sum(x["sent"] for x in sim_records)
    total_ack=sum(x["acknowledged"] for x in sim_records)
    total_response=sum(x["responded"] for x in sim_records)
    ack_share=total_ack/max(total_sent,1)
    response_share=total_response/max(total_sent,1)
    min_ack=float(RULES["control"].get("min_ack_share",0.9))
    if ack_share < min_ack or response_share < min_ack:
        status="fail"
        summary=f"Имитатор: подтверждение {ack_share:.1%}, отклик {response_share:.1%}; требуется не менее {min_ack:.1%}"
        obstacles=[{"check":"S3.2","reason":summary,"field":"simulator","asset":x["asset_id"]} for x in sim_records if x["acknowledged"]<x["sent"] or x["responded"]<x["sent"]]
    else:
        status="pass"
        summary=f"Имитатор подтвердил отправку, приём и отклик: {total_sent} команд, ACK {ack_share:.1%}, отклик {response_share:.1%}"
        obstacles=[]
    # Historical signals are evidence only; missing historical command traces are disclosed.
    history_cols=set(I.tel.columns) if I.tel is not None else set()
    hist_ok=all(any("setpoint_received" in c and c.startswith(a.get("asset_id","")) for c in history_cols)
                and any(c.startswith(a.get("asset_id","")) and "power_kW (" in c and "setpoint" not in c for c in history_cols)
                for a in assets)
    checks=[
        _check_result("S3.1","Исторический отклик (подтверждение и мощность)",
            "pass" if hist_ok else "unavailable",
            "В телеметрии есть setpoint_received и фактическая мощность; отправка команды и полный цикл дополнительно проверяются имитатором S3.2" if hist_ok else "Нет достаточных исторических сигналов подтверждения/мощности; функциональный цикл проверяется отдельным тестом имитатора",
            "telemetry.csv",h,
            [] if hist_ok else [{"check":"S3.1","reason":"Недостаточно исторических сигналов setpoint_received и power","field":"telemetry.csv","asset":a.get("asset_id")} for a in assets],
            None if hist_ok else "Подключить архив команд или подтвердить цикл через тестовый контур"),
        _check_result("S3.2","Тест контура на имитаторе (отправка/приём/отклик)",
            status,summary,"simulator",h,obstacles,
            None if status=="pass" else "Проверить доступность имитатора и отклик активов")
    ]
    checks[1]["evidence"]["simulation_results"]=sim_records
    return checks

def stage4(I) -> List[Dict]:
    h=I.hashes()[4]
    oid=I.passport.get("object_id",I.folder.name)
    checks=[]
    required_fields=RULES["dashboard"]["required_passport_fields"]
    missing=[]
    for field in required_fields:
        value=I.passport
        for part in field.split("."):
            value=value.get(part) if isinstance(value,dict) else None
        if value is None or value=="" or (isinstance(value,dict) and not value):
            missing.append(field)
    coords=I.passport.get("coordinates")
    if isinstance(coords,dict) and not all(k in coords and coords[k] is not None for k in ("lat","lon")):
        missing.append("coordinates.lat/lon")
    checks.append(_check_result("S4.1","Паспорт (адрес и координаты)",
        "pass" if not missing else "fail",
        "Обязательные поля паспорта заполнены" if not missing else f"Не заполнены поля: {missing}",
        "object.json",h,
        [{"check":"S4.1","reason":f"Отсутствует или пустое поле {f}","field":f,"asset":oid} for f in missing],
        None if not missing else "Заполнить паспорт объекта"))
    required=RULES["dashboard"]["required_blocks"]
    blocks=I.dash.get("blocks",[])
    if isinstance(blocks,dict):
        available=set(blocks.keys()); block_items=[{"id":k,**(v if isinstance(v,dict) else {})} for k,v in blocks.items()]
    else:
        block_items=[b for b in blocks if isinstance(b,dict)]
        available={b.get("id",b.get("key")) for b in blocks if isinstance(b,dict)}
        available.update(b for b in blocks if isinstance(b,str))
    missing_blocks=[x for x in required if x not in available]
    checks.append(_check_result("S4.2","Четыре обязательных блока дашборда",
        "pass" if not missing_blocks else "fail",
        "Все обязательные блоки присутствуют" if not missing_blocks else f"Отсутствуют блоки: {missing_blocks}",
        "dashboard configuration",h,
        [{"check":"S4.2","reason":f"Отсутствует блок {b}","field":"blocks","asset":oid} for b in missing_blocks],
        None if not missing_blocks else "Добавить обязательные блоки"))
    bad_bindings=[]
    for b in block_items:
        bid=b.get("id",b.get("key","unknown"))
        bound=b.get("object_id")
        source=str(b.get("data_source",""))
        if bound != oid or (source and not (source==oid or source.startswith(oid+"/"))):
            bad_bindings.append((bid,bound,source))
    checks.append(_check_result("S4.3","Привязка блоков к текущему объекту",
        "pass" if not bad_bindings else "fail",
        "Все блоки привязаны к текущему объекту" if not bad_bindings else f"Неверные привязки: {bad_bindings[:5]}",
        "dashboard configuration",h,
        [{"check":"S4.3","reason":f"Блок {bid} связан с {bound}, источник {source}","field":"blocks","asset":oid} for bid,bound,source in bad_bindings],
        None if not bad_bindings else "Исправить привязку блоков к объекту"))
    acl=I.dash.get("acl",{}) or {}
    principals=acl.get("principals",{}) if isinstance(acl,dict) else {}
    operator=principals.get("operator",[])
    public=bool(acl.get("public",False)) if isinstance(acl,dict) else True
    acl_ok=(operator==["read"] or (isinstance(operator,list) and set(operator)=={"read"})) and not public
    checks.append(_check_result("S4.4","Права доступа (operator read, public off)",
        "pass" if acl_ok else "fail",
        "Оператор имеет только read; публичный доступ отключён" if acl_ok else f"Некорректные права: operator={operator}, public={public}",
        "dashboard configuration",h,
        [] if acl_ok else [{"check":"S4.4","reason":"Нарушены права оператора или включён публичный доступ","field":"acl","asset":oid}],
        None if acl_ok else "Оставить оператору только read и отключить public"))
    accept=I.accept
    accepted=bool(accept and accept.get("by") and accept.get("role")=="Ответственный" and accept.get("dash_hash")==h)
    checks.append(_check_result("S4.5","Приёмка дашбордов ответственным",
        "pass" if accepted else ("pending" if not accept else "fail"),
        "Дашборды приняты ответственным; хэш конфигурации совпадает" if accepted else "Ожидается действующая приёмка ответственным" if not accept else "Приёмка устарела или роль/хэш не совпадает",
        "manual acceptance",h,
        [] if accepted or not accept else [{"check":"S4.5","reason":"Конфигурация изменилась после приёмки или неверная роль","field":"acceptance","asset":oid}],
        None if accepted else "Ответственному повторно принять текущую конфигурацию"))
    return checks

def get_dashboard_template() -> str:
    return (Path(__file__).parent.parent/"dashboard_template.html").read_text(encoding="utf-8")

def validate_inputs(I) -> bool:
    return bool(I.passport and I.passport.get("object_id") and I.inv is not None)

def get_simulation_mode(I) -> str:
    return I.sim.get("mode","ok") if I.sim else "ok"

def get_asset_signals(I, asset_id: str) -> List[str]:
    for asset in I.passport.get("assets",[]):
        if asset.get("asset_id")==asset_id:
            return asset.get("signals",[])
    return []
